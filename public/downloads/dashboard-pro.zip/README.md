# Admin Dashboard Pro

A complete admin layout with responsive sidebar, hamburger menu, stats cards, transaction tables, and activity feeds.

---

## 📦 What's Inside

```
dashboard-pro/
├── components/
│   └── templates/
│       └── admin/
│           ├── AdminLayout.jsx          # Responsive layout with sidebar & topbar
│           └── AdminLayout.module.css   # Complete styling with mobile breakpoints
├── app/
│   ├── admin/
│   │   ├── page.js                      # Dashboard page with stats, tables, activity
│   │   └── admin.module.css             # Dashboard-specific responsive styles
│   └── globals.css                      # Design token system & global styles
└── README.md                            # This file
```

## 🚀 Quick Start

### 1. Copy the files into your Next.js project

Copy the `components/templates/admin/` directory into your project. Copy `app/admin/` into your `app/` directory.

### 2. Merge global CSS tokens

Merge the CSS custom properties from `app/globals.css` into your own global stylesheet.

### 3. Use the AdminLayout wrapper

```jsx
import AdminLayout from '@/components/templates/admin/AdminLayout';

export default function MyAdminPage() {
  return (
    <AdminLayout>
      <h1>My Custom Admin Page</h1>
      {/* Your content here */}
    </AdminLayout>
  );
}
```

### 4. Features

- ✅ **Responsive sidebar** — slides in/out on mobile with overlay backdrop
- ✅ **Hamburger menu** — toggles sidebar with smooth animation
- ✅ **Click outside to close** — tap the overlay to dismiss on mobile
- ✅ **Auto-hide on resize** — sidebar auto-closes below 768px
- ✅ **Scroll lock** — prevents body scroll when mobile sidebar is open
- ✅ **Adaptive topbar** — search and username hide on small screens

## 🤖 AI Integration Prompt

```
Act as an Expert React & Next.js Engineer.
I have downloaded the "Admin Dashboard Pro" UI template from Lumino.
My current project setup is: [INSERT YOUR PROJECT SETUP HERE - e.g., Next.js 14 App Router, Tailwind/Vanilla CSS].

Please help me integrate this admin layout into my project without breaking my existing code.
Follow these rules strictly:
1. Adapt the global CSS variables and design tokens to match my existing theme.
2. The AdminLayout component should wrap my admin pages as a layout shell.
3. Update the import paths to match my specific project architecture.
4. Do not overwrite my layout.js, globals.css, or root routing without asking first.
5. Help me add new sidebar navigation items and connect them to my existing routes.
```

## 📋 Requirements

- **Next.js** 14+ (App Router)
- **React** 18+
- No additional npm dependencies required.

## 📄 License

Free for personal and commercial use.

---

Built with ❤️ by **Lumino UI Library**
