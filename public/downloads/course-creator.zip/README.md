# Course Creator Wizard

A complete 4-step course creation wizard with validation, drag & drop curriculum builder, and CSS theming system.

---

## 📦 What's Inside

```
course-creator/
├── components/
│   ├── stepper/         # StepperWizard, StepIndicator, StepNavigation
│   ├── steps/           # StepBasics, StepDescription, StepCurriculum, StepMedia, StepPricing, StepSettings, StepReview
│   ├── curriculum/      # CurriculumBuilder, SectionCard, LessonItem
│   ├── media/           # ImageUploader, VideoEmbed
│   └── ui/              # TextInput, TextArea, SelectDropdown, TagInput, Toggle, RadioGroup, Accordion, Modal, Toast, etc.
├── hooks/
│   ├── useFormState.js  # Central form state management
│   └── useDragReorder.js # Drag & drop reordering hook
├── lib/
│   ├── constants.js     # Step definitions, categories, languages
│   ├── utils.js         # Helper utilities
│   └── validation.js    # Form validation rules
├── app/
│   ├── create/          # Page entry point (page.js)
│   └── globals.css      # Design token system & global styles
└── README.md            # This file
```

## 🚀 Quick Start

### 1. Copy the files into your Next.js project

Copy the `components/`, `hooks/`, and `lib/` directories into your project root. Copy the page from `app/create/` into your `app/` directory.

### 2. Merge global CSS tokens

Open `app/globals.css` from this package and merge the CSS custom properties (design tokens) into your own `globals.css`. The key variables are:

```css
:root {
  --color-primary: #00e6b8;
  --color-bg-primary: #ffffff;
  --font-family: 'Inter', sans-serif;
  /* ... see globals.css for the full list */
}
```

### 3. Update import paths

All imports use the `@/` alias (e.g., `import TextInput from '@/components/ui/TextInput'`). Make sure your `jsconfig.json` or `tsconfig.json` has:

```json
{
  "compilerOptions": {
    "paths": {
      "@/*": ["./*"]
    }
  }
}
```

### 4. Add the Google Font

Add this to your `<head>` or `layout.js`:

```html
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
```

## 🤖 AI Integration Prompt

Use this prompt with ChatGPT, Claude, or any AI assistant to integrate this template seamlessly:

```
Act as an Expert React & Next.js Engineer.
I have downloaded the "Course Creator Wizard" UI template from Lumino.
My current project setup is: [INSERT YOUR PROJECT SETUP HERE - e.g., Next.js 14 App Router, Tailwind/Vanilla CSS].

Please help me integrate this component seamlessly into my project without breaking my existing code.
Follow these rules strictly:
1. Adapt the global CSS variables and design tokens to match my existing theme.
2. Resolve any missing dependencies (like Lucide icons or utility libraries) gracefully.
3. Update the import paths (components, hooks, lib) to match my specific project architecture.
4. Do not overwrite my layout.js, globals.css, or root routing without explicitly asking first.
5. Break down the integration step-by-step so I can review each part.
```

## 📋 Requirements

- **Next.js** 14+ (App Router)
- **React** 18+
- No additional npm dependencies required — all components use vanilla CSS modules.

## 📄 License

Free for personal and commercial use. Attribution appreciated but not required.

---

Built with ❤️ by **Lumino UI Library**
