# E-commerce Product Cards

Responsive product cards with color selection, hover effects, and add-to-cart functionality.

---

## 📦 What's Inside

```
ecommerce-cards/
├── components/
│   └── templates/
│       └── ecommerce/
│           ├── ProductGrid.jsx           # Product grid with cards
│           └── ProductGrid.module.css    # Styled product layout
├── app/
│   ├── ecommerce/
│   │   └── page.js                       # E-commerce page entry point
│   └── globals.css                       # Design token system
└── README.md
```

## 🚀 Quick Start

### 1. Copy files into your project
### 2. Merge design tokens from `globals.css`
### 3. Use the ProductGrid component

```jsx
import ProductGrid from '@/components/templates/ecommerce/ProductGrid';

export default function ShopPage() {
  return <ProductGrid />;
}
```

## 🤖 AI Integration Prompt

```
Act as an Expert React & Next.js Engineer.
I have downloaded the "E-commerce Product Cards" UI template from Lumino.
My current project setup is: [INSERT YOUR PROJECT SETUP HERE].

Please help me integrate these product cards into my project:
1. Connect the product data to my database/CMS/API.
2. Implement the add-to-cart functionality with my cart state management.
3. Adapt the CSS design tokens to my existing theme.
4. Replace placeholder images with my actual product images.
5. Update import paths for my project structure.
```

## 📋 Requirements

- **Next.js** 14+ (App Router) | **React** 18+

## 📄 License

Free for personal and commercial use.

---

Built with ❤️ by **Lumino UI Library**
