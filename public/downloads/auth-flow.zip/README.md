# Authentication Flow

Login, signup, and password recovery pages with client-side validation and smooth animations.

---

## 📦 What's Inside

```
auth-flow/
├── components/
│   └── templates/
│       └── auth/
│           ├── AuthForm.jsx           # Login/Signup form with mode toggle
│           └── AuthForm.module.css    # Styled auth form with animations
├── app/
│   ├── auth/
│   │   └── page.js                    # Auth page entry point
│   └── globals.css                    # Design token system
└── README.md
```

## 🚀 Quick Start

### 1. Copy the files into your Next.js project

Copy `components/templates/auth/` and `app/auth/` into your project.

### 2. Merge design tokens from `globals.css`

### 3. Use the AuthForm component

```jsx
import AuthForm from '@/components/templates/auth/AuthForm';

export default function LoginPage() {
  return <AuthForm />;
}
```

## 🤖 AI Integration Prompt

```
Act as an Expert React & Next.js Engineer.
I have downloaded the "Authentication Flow" UI template from Lumino.
My current project setup is: [INSERT YOUR PROJECT SETUP HERE].

Please help me integrate this authentication flow into my project:
1. Connect the form submission to my authentication API (e.g., NextAuth, Supabase, Firebase).
2. Adapt the CSS design tokens to my existing theme.
3. Add proper error handling and loading states.
4. Update import paths for my project structure.
5. Do not overwrite my existing layout or routing without asking first.
```

## 📋 Requirements

- **Next.js** 14+ (App Router) | **React** 18+

## 📄 License

Free for personal and commercial use.

---

Built with ❤️ by **Lumino UI Library**
