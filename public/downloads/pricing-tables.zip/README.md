# Pricing Tables

Dynamic pricing components with monthly/annual toggle and recommendation badges.

---

## 📦 What's Inside

```
pricing-tables/
├── components/
│   └── templates/
│       └── pricing/
│           ├── PricingCards.jsx           # Pricing cards with toggle
│           └── PricingCards.module.css    # Styled pricing layout
├── app/
│   ├── pricing/
│   │   └── page.js                       # Pricing page entry point
│   └── globals.css                       # Design token system
└── README.md
```

## 🚀 Quick Start

### 1. Copy files into your project
### 2. Merge design tokens from `globals.css`
### 3. Use the PricingCards component

```jsx
import PricingCards from '@/components/templates/pricing/PricingCards';

export default function PricingPage() {
  return <PricingCards />;
}
```

## 🤖 AI Integration Prompt

```
Act as an Expert React & Next.js Engineer.
I have downloaded the "Pricing Tables" UI template from Lumino.
My current project setup is: [INSERT YOUR PROJECT SETUP HERE].

Please help me integrate these pricing tables into my project:
1. Connect the pricing plans to my Stripe/payment API.
2. Adapt the CSS design tokens to my existing theme.
3. Make the plan data dynamic (fetched from my database/API).
4. Update import paths for my project structure.
5. Do not overwrite existing files without asking first.
```

## 📋 Requirements

- **Next.js** 14+ (App Router) | **React** 18+

## 📄 License

Free for personal and commercial use.

---

Built with ❤️ by **Lumino UI Library**
